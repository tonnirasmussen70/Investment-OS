
## Emerging Compounder Radar

Radaren genereres automatisk til `data/compounder_radar.xlsx` af workflowet
`.github/workflows/compounder_radar.yml`. Workflowet kan startes manuelt under
**Actions → Emerging Compounder Radar → Run workflow** og kører desuden hver
søndag kl. 07:00 UTC.

Generatoren henter S&P 500 og Nasdaq-100, laver en hurtig momentum-shortlist og
henter derefter fundamentale data for de stærkeste kandidater. Resultatet er en
rangering af op til 30 selskaber. Datamangler reducerer `AI_Confidence`, og
radaren skal bruges som screening og beslutningsstøtte — ikke som en automatisk
købsanbefaling.
