# Installation

Copy these files into the root of Investment-OS:

- scripts/generate_compounder_radar.py
- .github/workflows/compounder_radar.yml

Optionally append README_APPEND.md to README.md.

Then commit and push the changes. In GitHub:
Actions → Emerging Compounder Radar → Run workflow

The workflow will generate:
data/compounder_radar.xlsx
